function paridade(n) {
    if (n % 2 == 0) return "par";
    return "ímpar"
}

module.exports = paridade
