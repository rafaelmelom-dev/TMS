const paridade = require('./index');

test('número par', () => {
  expect(paridade(2)).toBe("par");
});

test('número ímpar', () => {
  expect(paridade(3)).toBe("ímpar");
});
