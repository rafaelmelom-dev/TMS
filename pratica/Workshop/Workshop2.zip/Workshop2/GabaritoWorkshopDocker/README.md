A atividade proposta, tinha como objetivo os alunos criarem um volume, então como resultado produziríamos um arquivo chamado **access.log** dentro da pasta logs.
