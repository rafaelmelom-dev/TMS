
package com.refactor;

public class Main {
    public static void main(String[] args) {
        System.out.println("Refactor Workshop - rode cada demonstração isoladamente");
    }
}
